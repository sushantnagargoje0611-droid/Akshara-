package com.example.privateassistant

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.AlarmClock

class CommandRouter(private val ctx: Context, private val llm: LocalLlm?) {
    private var pending: (() -> String)? = null   // action waiting for "yes"

    fun handle(input: String): String {
        val t = input.trim(); val l = t.lowercase()
        if (l == "yes" || l == "confirm") { val p = pending; pending = null; return p?.invoke() ?: "Nothing to confirm." }
        if (l == "no" || l == "cancel") { pending = null; return "Cancelled." }

        return when {
            l.startsWith("alarm ") -> setAlarm(l.removePrefix("alarm ").trim())
            l.startsWith("note ") -> { MessageStore.saveNote(ctx, t.drop(5)); "Note saved (encrypted)." }
            l == "summarize whatsapp" -> summarize()
            l.startsWith("reply ") -> draftReply(t.drop(6))
            l.startsWith("whatsapp ") -> openChat(t.drop(9))
            l == "wipe data" -> { MessageStore.wipeAll(ctx); "All data wiped." }
            else -> llm?.ask(t) ?: "Command not recognised. Try: alarm 7:30, note ..., summarize whatsapp, reply <name>: <text>"
        }
    }

    private fun setAlarm(hhmm: String): String {
        val (h, m) = hhmm.split(":").map { it.toInt() }
        ctx.startActivity(Intent(AlarmClock.ACTION_SET_ALARM)
            .putExtra(AlarmClock.EXTRA_HOUR, h).putExtra(AlarmClock.EXTRA_MINUTES, m)
            .putExtra(AlarmClock.EXTRA_SKIP_UI, true).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        return "Alarm set for %02d:%02d".format(h, m)
    }

    private fun summarize(): String {
        val msgs = MessageStore.messages.takeLast(30)
        if (msgs.isEmpty()) return "No new WhatsApp messages."
        val raw = msgs.joinToString("\n") { "${it.sender}: ${it.text}" }
        return llm?.ask("Summarize these messages briefly by person:\n$raw") ?: raw
    }

    // "reply Rahul: I'll be late" -> asks you to confirm, then sends
    private fun draftReply(arg: String): String {
        val (name, text) = arg.split(":", limit = 2).let { it[0].trim() to it.getOrElse(1) { "" }.trim() }
        val msg = MessageStore.messages.lastOrNull { it.sender.contains(name, true) && it.replyAction != null }
            ?: return "No recent message from $name to reply to."
        pending = { if (WhatsAppListener.sendReply(ctx, msg, text)) "Sent to ${msg.sender}." else "Reply failed." }
        return "Send to ${msg.sender}: \"$text\"? (yes / no)"
    }

    // "whatsapp 919876543210 hello" -> opens chat prefilled; you tap Send
    private fun openChat(arg: String): String {
        val num = arg.substringBefore(" "); val text = Uri.encode(arg.substringAfter(" ", ""))
        ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/$num?text=$text"))
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        return "Opened WhatsApp. Tap Send."
    }
}
