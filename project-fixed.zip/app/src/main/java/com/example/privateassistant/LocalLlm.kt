package com.example.privateassistant

import android.content.Context
import com.google.mediapipe.tasks.genai.llminference.LlmInference

/** Runs fully offline. Copy a Gemma .task model to the app's files dir first. */
class LocalLlm(ctx: Context, modelFile: String = "gemma.task") {
    private val llm = LlmInference.createFromOptions(
        ctx, LlmInference.LlmInferenceOptions.builder()
            .setModelPath("${ctx.filesDir}/$modelFile").setMaxTokens(512).build())

    fun ask(prompt: String): String = llm.generateResponse(prompt)
}
