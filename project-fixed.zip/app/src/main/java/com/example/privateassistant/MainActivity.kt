package com.example.privateassistant

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import androidx.activity.compose.setContent
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.*
import android.Manifest

class MainActivity : FragmentActivity() {
    private var unlocked by mutableStateOf(false)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 1)
        authenticate()
        setContent { MaterialTheme { if (unlocked) Chat() else Text("Locked", Modifier.padding(32.dp)) } }
    }

    private fun authenticate() {
        val prompt = BiometricPrompt(this, ContextCompat.getMainExecutor(this),
            object : BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationSucceeded(r: BiometricPrompt.AuthenticationResult) { unlocked = true }
            })
        prompt.authenticate(BiometricPrompt.PromptInfo.Builder()
            .setTitle("Unlock assistant")
            .setAllowedAuthenticators(BiometricManager.Authenticators.BIOMETRIC_WEAK or BiometricManager.Authenticators.DEVICE_CREDENTIAL)
            .build())
    }

    @Composable
    fun Chat() {
        val router = remember {
            CommandRouter(this, runCatching { LocalLlm(this) }.getOrNull())  // null if model missing
        }
        val gate = remember { runCatching { VoiceGate(this) }.getOrNull() }
        var input by remember { mutableStateOf("") }
        val log = remember { mutableStateListOf("Assistant ready.") }

        Column(Modifier.fillMaxSize().padding(16.dp)) {
            Button(onClick = { startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) }) {
                Text("Enable WhatsApp access")
            }
            LazyColumn(Modifier.weight(1f)) { items(log) { Text(it, Modifier.padding(vertical = 4.dp)) } }
            Row {
                Button({
                    if (gate == null) { log.add("Voice models missing."); return@Button }
                    lifecycleScope.launch {
                        if (!gate.isEnrolled()) {
                            log.add("Enrolling: say 3 different sentences, one at a time.")
                            val ok = withContext(Dispatchers.IO) { gate.enroll { n -> runOnUiThread { log.add("Sentence $n... speak now") } } }
                            log.add(if (ok) "Voice saved. Tap Mic to give commands." else "Enrollment failed, try again.")
                        } else {
                            log.add("Listening...")
                            val h = withContext(Dispatchers.IO) { gate.listen() }
                            if (!gate.isOwner(h.vec)) log.add("Voice not recognised. Ignored.")
                            else { log.add("You: ${h.text}"); log.add(router.handle(h.text)) }
                        }
                    }
                }) { Text("Mic") }
                OutlinedTextField(input, { input = it }, Modifier.weight(1f))
                Button({ log.add("You: $input"); log.add(router.handle(input)); input = "" }) { Text("Send") }
            }
        }
    }
}
