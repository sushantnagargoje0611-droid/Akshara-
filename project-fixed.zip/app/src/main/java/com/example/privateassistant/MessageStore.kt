package com.example.privateassistant

import android.app.Notification
import android.content.Context
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

data class WaMessage(val sender: String, val text: String, val time: Long,
                     val replyAction: Notification.Action?)

object MessageStore {
    val messages = mutableListOf<WaMessage>()   // live, in memory only

    private fun prefs(ctx: Context) = EncryptedSharedPreferences.create(
        ctx, "secure_store",
        MasterKey.Builder(ctx).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build(),
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM)

    fun saveNote(ctx: Context, note: String) {
        val p = prefs(ctx); val all = p.getStringSet("notes", emptySet())!!.toMutableSet()
        all.add(note); p.edit().putStringSet("notes", all).apply()
    }
    fun wipeAll(ctx: Context) { prefs(ctx).edit().clear().apply(); messages.clear() }
}
