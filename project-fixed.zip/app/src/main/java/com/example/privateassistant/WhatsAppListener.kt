package com.example.privateassistant

import android.app.Notification
import android.app.RemoteInput
import android.content.Intent
import android.os.Bundle
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

class WhatsAppListener : NotificationListenerService() {

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (sbn.packageName != "com.whatsapp") return
        val n = sbn.notification
        if (n.flags and Notification.FLAG_GROUP_SUMMARY != 0) return
        val title = n.extras.getCharSequence(Notification.EXTRA_TITLE)?.toString() ?: return
        val text = n.extras.getCharSequence(Notification.EXTRA_TEXT)?.toString() ?: return
        val reply = n.actions?.firstOrNull { it.remoteInputs?.isNotEmpty() == true }
        MessageStore.messages.add(WaMessage(title, text, sbn.postTime, reply))
    }

    companion object {
        /** Sends a reply via WhatsApp's own notification quick-reply. Call only after user confirms. */
        fun sendReply(ctx: android.content.Context, msg: WaMessage, text: String): Boolean {
            val action = msg.replyAction ?: return false
            val input = action.remoteInputs?.firstOrNull() ?: return false
            val intent = Intent()
            val bundle = Bundle().apply { putCharSequence(input.resultKey, text) }
            RemoteInput.addResultsToIntent(arrayOf(input), intent, bundle)
            return try { action.actionIntent.send(ctx, 0, intent); true }
            catch (e: Exception) { false }
        }
    }
}
