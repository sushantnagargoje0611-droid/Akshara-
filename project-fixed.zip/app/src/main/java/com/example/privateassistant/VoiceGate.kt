package com.example.privateassistant

import android.annotation.SuppressLint
import android.content.Context
import android.media.*
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import org.json.JSONObject
import org.vosk.Model
import org.vosk.Recognizer
import org.vosk.SpeakerModel
import kotlin.math.sqrt

/** Offline speech-to-text + speaker check. Only YOUR voice gets through. */
class VoiceGate(private val ctx: Context) {
    // Unzip these into filesDir: vosk-model-small-en-in-0.4 -> "vosk-model", vosk-model-spk-0.4 -> "vosk-spk"
    private val model = Model("${ctx.filesDir}/vosk-model")
    private val spk = SpeakerModel("${ctx.filesDir}/vosk-spk")
    private val rate = 16000
    private val threshold = 0.45   // lower = stricter. Tune after testing.

    private val prefs = EncryptedSharedPreferences.create(
        ctx, "voice_profile",
        MasterKey.Builder(ctx).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build(),
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM)

    fun isEnrolled() = prefs.contains("voiceprint")

    data class Heard(val text: String, val vec: DoubleArray?)

    /** Records until you pause (max 6s), returns text + voiceprint. Call off the main thread. */
    @SuppressLint("MissingPermission")
    fun listen(maxSeconds: Int = 6): Heard {
        val rec = Recognizer(model, rate.toFloat(), spk)
        val buf = ShortArray(4000)
        val ar = AudioRecord(MediaRecorder.AudioSource.MIC, rate, AudioFormat.CHANNEL_IN_MONO,
            AudioFormat.ENCODING_PCM_16BIT, buf.size * 4)
        ar.startRecording()
        val end = System.currentTimeMillis() + maxSeconds * 1000
        var json: String? = null
        while (System.currentTimeMillis() < end) {
            val n = ar.read(buf, 0, buf.size)
            if (n > 0 && rec.acceptWaveForm(buf, n)) { json = rec.result; break }
        }
        ar.stop(); ar.release()
        val o = JSONObject(json ?: rec.finalResult); rec.close()
        val arr = o.optJSONArray("spk")
        val vec = arr?.let { a -> DoubleArray(a.length()) { a.getDouble(it) } }
        return Heard(o.optString("text"), vec)
    }

    /** Say 3 different sentences. Averages them into your voiceprint (stored encrypted). */
    fun enroll(onPrompt: (Int) -> Unit): Boolean {
        val vecs = mutableListOf<DoubleArray>()
        repeat(3) { onPrompt(it + 1); listen(8).vec?.let(vecs::add) }
        if (vecs.size < 3) return false
        val avg = DoubleArray(vecs[0].size) { i -> vecs.sumOf { it[i] } / vecs.size }
        prefs.edit().putString("voiceprint", avg.joinToString(",")).apply()
        return true
    }

    fun isOwner(vec: DoubleArray?): Boolean {
        val saved = prefs.getString("voiceprint", null)?.split(",")?.map { it.toDouble() } ?: return false
        if (vec == null || vec.size != saved.size) return false
        var dot = 0.0; var a = 0.0; var b = 0.0
        for (i in vec.indices) { dot += vec[i] * saved[i]; a += vec[i] * vec[i]; b += saved[i] * saved[i] }
        return 1 - dot / (sqrt(a) * sqrt(b)) < threshold
    }

    fun clearProfile() = prefs.edit().clear().apply()
}
